-------------------------------------------------------------
INTRODUCTION 
-------------------------------------------------------------
                             
Welcome to the Hexen: Deathkings of the Dark Citadel README
section. 

Hexen: Deathkings consists of 20 all new levels of skull-bashing
fun for use with the original Hexen version 1.1. If you have
Hexen but it's not version 1.1., don't fret! There is a patch
included on the Hexen: Deathkings CD that will upgrade you from
version 1.0 to version 1.1.

If you don't have Hexen at all, that's not a problem either.
We've included Hexen version 1.1 as well as a few other items
on the CD-ROM in a locked format that you can purchase through
our 1-800-idgames order number.  To enter the id Store, you must
be in Windows and go to the "idstuff" subdirectory on the Hexen
CD-ROM. Run the INSTALL program to install the id Store on your
hard drive.

Since this is an add-on product for Hexen, everything in the
Hexen README will apply to Hexen: Deathkings as well.

-------------------
MULTI-PLAYER UPDATE
-------------------

STARTING A GAME:
Hexen 1.1 and Hexen: Deathkings no longer have the option of
using SETUP.EXE to start a multi-player game. You must use
DM (easiest) or SERSETUP.EXE/IPXSETUP.EXE (hardest) to start
a multiplayer game.

LOADING A GAME:
When loading a multi-player save game, you must specify the
-loadgame parameter to DM or SERSETUP/IPXSETUP.
E.G. DM -LOADGAME <#> where # is a number from 0-5

-------------------------------------------------------------
Hexen, the Hexen logo and Hexen likenesses are trademarks
of Raven Software, (C) 1995. GT Interactive is a trademark of
Goodtimes Entertainment. IBM is a registered trademark of 
International Business Machines, inc. Sound Blaster is a 
registered trademark of Creative Labs, inc. All other 
trademarks are the property of their respective companies.
